import React from "react";

const AdminDataAnalytics = () => {
  return <div>AdminDataAnalytics</div>;
};

export default AdminDataAnalytics;
