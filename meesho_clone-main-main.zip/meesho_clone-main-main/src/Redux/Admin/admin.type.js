export const ADMIN_DATA_LOADING = "admin/dataLoading";
export const ADMIN_DATA_SUCCESS = "admin/dataSuccess";
export const ADMIN_DATA_ERROR = "admin/dataError";

export const POST_ADMIN_DATA_SUCCESS = "postadmin/dataSuccess";
export const POST_ADMIN_DATA_ERROR = "postadmin/dataError";
export const POST_ADMIN_DATA_LOADING = "postadmin/dataLoading";

export const DELETE_ADMIN_DATA = "delete/adminData";

export const FILTERING_ADMIN_DATA = "filtering/admindata";
export const UPDATE_ADMIN_DATA = "update/adminData";
