export  const  AUTH_LOAD = "AUTH_LOAD";
export  const AUTH_SUCCESS = "AUTH_SUCCESS";
export  const AUTH_LOGOUT = "AUTH_LOGOUT";
export const  AUTH_ERROR = "AUTH_ERROR";
export  const POST_AUTH_SUCCESS = "POST_AUTH_SUCCESS";
export  const SET_CUR_USER = "SET_CUR_USER";
export  const SET_CUR_NAME = "SET_CUR_NAME";

